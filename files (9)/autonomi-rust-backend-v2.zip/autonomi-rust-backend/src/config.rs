use std::env;

/// Application configuration
/// Loads settings from environment variables with sensible defaults
#[derive(Debug, Clone)]
pub struct Config {
    /// AntTP service URL
    pub anttp_url: String,
    
    /// Server bind address
    pub bind_address: String,
    
    /// Log level
    pub log_level: String,
}

impl Config {
    /// Load configuration from environment
    pub fn from_env() -> Self {
        Self {
            anttp_url: env::var("ANTTP_BASE_URL")
                .unwrap_or_else(|_| "http://localhost:18888".to_string()),
            
            bind_address: env::var("BIND_ADDRESS")
                .unwrap_or_else(|_| "0.0.0.0:8000".to_string()),
            
            log_level: env::var("LOG_LEVEL")
                .unwrap_or_else(|_| "info".to_string()),
        }
    }
    
    /// Display configuration (for startup logging)
    pub fn display(&self) {
        println!("🦀 Configuration:");
        println!("   AntTP URL: {}", self.anttp_url);
        println!("   Bind Address: {}", self.bind_address);
        println!("   Log Level: {}", self.log_level);
    }
}

impl Default for Config {
    fn default() -> Self {
        Self {
            anttp_url: "http://localhost:18888".to_string(),
            bind_address: "0.0.0.0:8000".to_string(),
            log_level: "info".to_string(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_default_config() {
        let config = Config::default();
        assert_eq!(config.anttp_url, "http://localhost:18888");
        assert_eq!(config.bind_address, "0.0.0.0:8000");
        assert_eq!(config.log_level, "info");
    }
    
    #[test]
    fn test_config_clone() {
        let config = Config::default();
        let cloned = config.clone();
        assert_eq!(config.anttp_url, cloned.anttp_url);
    }
}
